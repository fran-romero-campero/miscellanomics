###############################################################
## Biología Molecular de Sistemas                            ##
## Grado en Bioquímica                                       ##         
## Universidad de Sevilla                                    ##
##                                                           ##
## Unidad 3. Construcción y Análisis de Redes Biológicas     ##
##                                                           ##
## Profs. Francisco J. Romero-Campero fran@us.es             ##
###############################################################

## Creamos la matriz de adyacencia de nuestra red ejemplo:
example.adjacency <- matrix(
  c(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0), 
  nrow=27, ncol=27)

## La librería R igraph proporciona funciones muy útiles para el análisis de redes o grafos. 
## Para instalarla y cargarla ejecuta las siguientes instrucciones:

install.packages("igraph")
library(igraph)

## Para crear la red de nuestro ejemplo a partir de la matriz de adyacencia example.adjacency 
## se utilila la función graph.adjacency que toma como dato de entrada la matriz de adyacencia 
## y el tipo de red (en nuestro caso no dirigida)

example.network <- graph.adjacency(example.adjacency, mode="undirected")
plot(example.network,vertex.size=10,vertex.label=NA,edge.label=NA,layout=layout.graphopt)
plot(example.network,vertex.size=8,edge.label=NA,layout=layout.graphopt)

## La función degree recibe como entrada una red y el identificador de un nodo y devuelve 
## el grado de dicho nodo en la red:

degree(example.network,20)
degree(example.network,5)

## Podemos calcular el coeficiente de agrupamiento de un nodo usando la función transitivity 
## tomando como entrada la red, el argumento type = “local” y el argumento vids con el 
## identificador del nodo en cuestión:

transitivity(example.network,type="local",vids="5")
transitivity(example.network,type="local",vids="6")
transitivity(example.network,type="local",vids="20")
transitivity(example.network,type="local",vids="23")


## Podemos obtener la distribución del grado de nodos de una red usando la función 
## degree.distribution con entrada sólo dicha red.
network.degree.distribution <- degree.distribution(example.network)

## Alternativamente podemos usar la función degree sin nodo de entrada y utilizar hist para 
## representarla
network.degrees <- degree(example.network)
network.degrees
degree.histogram <- hist(network.degrees,freq=FALSE,col="blue",xlab="Node degree", ylab="Probability",main="Degree distribution")

## Para calcular el coeficiente de agrupamiento medio de un red utilizamos la función 
## transitivity con argumentos la red a estudiar y type=”global”
transitivity(example.network,type="global")
example.network
## Podemos comprobar que la correspondiente nube de puntos aparentemente se ajusta a una 
## exponencial negativa. Para comprobar el ajuste de la nube de puntos a una exponencial 
## negativa podemos realizar una transformación logarítmica de ambos ejes (aplicando 
## logaritmo a los valores x e y, una vez eliminados los valores 0 ya que el log10(0) no
## está definido) y comprobar si se ajusta a una línea recta utilizando regresión lineal. 
## La función R lm permite realizar un análisis de regresión lineal:

network.degrees <- degree(example.network)
degree.histogram <- hist(network.degrees)

degrees.frequencies <-degree.histogram[["counts"]]
node.degrees <- degree.histogram[["mids"]]

log10.degrees.frequencies <- log10(degrees.frequencies[-3])
log10.node.degrees <- log10(node.degrees[-3])

plot(log10.node.degrees,log10.degrees.frequencies)

lm.r <- lm(log10.degrees.frequencies ~ log10.node.degrees)
summary(lm.r)

## La función de igraph power.law.fit que recibe como entrada la distribución del grado 
## de los nodos nos permite realizar un análisis estadístico basado en el test de 
## Kolmogorov-Smirnov sobre el ajuste de la topología de una red a la propiedad libre de 
## escala. Esta función devuelve un objeto donde el valor KS.p es el p-valor correspondiente 
## a rechazar la hipotesis nula que en este caso aserta que la red estudiada es libre de 
## escala. Por lo tanto, un valor alto de KS.p indica la ausencia de evidencia para afirmar 
## que la red estudiada no es libre de escala:

network.degree.distribution <- degree.distribution(example.network)
fit.scale.free <- power.law.fit(network.degree.distribution)
fit.scale.free[["KS.p"]]

## La mayoría de los nodos en la redes libre de escala presentan un número pequeño de vecinos. 
## Sin embargo existen unos pocos nodos destacados que tiene un alto número de vecinos. Este 
## último tipo de nodos se denominan hubs. La función hub.score de igraph que recibe como 
## entrada una red calcula y almacena en el valor vector una puntuación entre uno y cero para 
## cada nodo de la red. Cuánto mayor sea esta puntuación de un nodo más se ajustan sus 
## características a las de un hub de la red.

network.hub.scores <- hub.score(example.network)
hub.scores <- network.hub.scores[["vector"]]
names(hub.scores) <- 1:27
hub.scores

## Normalmente se consideran hubs el 5% de los nodos con mayor puntuación. Para ello los 
## ordenamos de forma decreciente y tomamos el 5% de los nodos 
sorted.hub.scores <- sort(hub.scores,decreasing=TRUE)
sorted.hub.scores
27*0.05

sorted.hub.scores[1:2]

hs <- quantile(hub.scores,probs = 0.95)

which(hub.scores > hs)

plot(example.network,vertex.size=4,edge.label=NA,layout=layout.graphopt)

## Usando la función average.path.length podemos calcular el camino mínimo medio entre nodos
average.path.length(example.network, directed=FALSE)

## Para comprobar si el coeficiente de agrupamiento en lo suficientemente alto y 
## la longitud media del camino mínimo entre nodos es lo suficientemente 
## pequeña como para considerarla de mundo pequeño es común generar redes libres de escala del 
## mismo orden y tamaño de la estudiada para estimar la probabilidad de que por pura 
## aleatoriedad se obtenga una red similar a la estudiada pero con una longitud media del 
## camino mínimo entre nodos inferior. La función barabasi.game permite generar redes libres 
## de escala con el número de nodos proporcionado en el argumento n. Esta función genera de 
## forma incremental la red añadiendo en cada paso un nodo y el número de aristas especificados 
## en el argumento out.seq (el primer valor de este vector se ignora). Por último el parámetro 
## directed=FALSE indica que generaremos una red no dirigida. 
transitivity(example.network,type = "global")
example.network
number.of.added.edges <- c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1)
sum(number.of.added.edges)
random.scale.free.graph <- barabasi.game(n=27,out.seq=number.of.added.edges,directed=FALSE)
plot(random.scale.free.graph,vertex.size=4,vertex.label=NA,edge.label=NA,layout=layout.graphopt)
average.path.length(random.scale.free.graph, directed=FALSE)
transitivity(random.scale.free.graph)

clustering.coefficients <- vector(length=1000)

for(i in 1:1000)
{
  print(i)
  random.scale.free.graph <- barabasi.game(n=27,out.seq=number.of.added.edges,directed=FALSE)
  clustering.coefficients[i] <- transitivity(random.scale.free.graph)
}

sum(clustering.coefficients > 0.1401869) / 1000

## Los ciclos de luz y oscuridad ejercen una fuerte influencia sobre los procesos metabólicos 
## y fisiológicos de las plantas. Para estudiar esta influencia se utilizó como organismo modelo
## la planta Arabidopsis thaliana, ecotipo Columbia-0 (Col-0), cultivada en períodos de 12 horas 
## de luz y 12 horas de oscuridad. Se tomaron muestras de RNA con 3 réplicas biológicas durante 
## un día a intervalos de 4 horas (ZT0, ZT4, ZT8, ZT12, ZT16 y ZT20). El periodo de luz va desde 
## ZT0 a ZT12 y el de oscuridad de ZT12 a ZT0. Usando placas de microarray ATH1-121501 se 
## obtuvieron los siguientes ficheros .CEL:                                                                              
##                                                                                                                       
## * Muestras a ZT0: zt00_1.cel.gz, zt00_2.cel.gz y zt00_3.cel.gz.                                                          
## * Muestras a ZT4: zt04_1.cel.gz, zt04_2.cel.gz y zt04_3.cel.gz.                                                          
## * Muestras a ZT8: zt08_1.cel.gz, zt08_2.cel.gz y zt08_3.cel.gz.                                                          
## * Muestras a ZT12: zt12_1.cel.gz, zt12_2.cel.gz y zt12_3.cel.gz.                                                      
## * Muestras a ZT16: zt16_1.cel.gz, zt16_2.cel.gz y zt16_3.cel.gz.                                                      
## * Muestras a ZT20: zt20_1.cel.gz, zt20_2.cel.gz y zt20_3.cel.gz.                                                      
##                                                                                                                       
## Este estudio corresponde al artículo: Sugars and Circadian Regulation Make a Major 
## Contributions to the Global Regulation of Diurnal Gene Expression in Arabidopsis, 
## The Plant Cell, 17, 3257 - 3281, 2005.                          
##       
## Se pide realizar los siguientes apartados: 
##
## Paso 1: Análisis de datos transcriptómicos masivos. Selección de genes expresados de
##         forma diferencial de acuerdo a un criterio que combine un cambio del factor de 
##         proporcionalidad o fold-change de 2 y un p-valor de 0.01

library(affy)
library(simpleaffy)
library(affyPLM)

microarrays <- ReadAffy(verbose=TRUE)
microarrays

quality.control <- qc(microarrays)
plot(quality.control)

microarray.data <- rma(microarrays)

expression.level <- exprs(microarray.data)

sampleID <- c("ZT0_1", "ZT0_2", "ZT0_3", "ZT4_1", "ZT4_2", "ZT4_3", "ZT8_1", "ZT8_2", "ZT8_3", "ZT12_1", "ZT12_2", "ZT12_3", "ZT16_1", "ZT16_2", "ZT16_3", "ZT20_1", "ZT20_2", "ZT20_3")
colnames(expression.level) <- sampleID

cond0h <- (expression.level[,"ZT0_1"] + expression.level[,"ZT0_2"] + expression.level[,"ZT0_3"])/3
cond4h <- (expression.level[,"ZT4_1"] + expression.level[,"ZT4_2"] + expression.level[,"ZT4_3"])/3
cond8h <- (expression.level[,"ZT8_1"] + expression.level[,"ZT8_2"] + expression.level[,"ZT8_3"])/3
cond12h <- (expression.level[,"ZT12_1"] + expression.level[,"ZT12_2"] + expression.level[,"ZT12_3"])/3
cond16h <- (expression.level[,"ZT16_1"] + expression.level[,"ZT16_2"] + expression.level[,"ZT16_3"])/3
cond20h <- (expression.level[,"ZT20_1"] + expression.level[,"ZT20_2"] + expression.level[,"ZT20_3"])/3

mean.expression <- matrix(c(cond0h,cond4h,cond8h,cond12h,cond16h,cond20h), nrow=6,ncol=length(cond0h),byrow=TRUE)
colnames(mean.expression) <- names(cond0h)
rownames(mean.expression) <- c("ZT0", "ZT4", "ZT8", "ZT12", "ZT16", "ZT20")

library(limma)

experiment.design <- model.matrix(~ -1+factor(c(1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6)))
colnames(experiment.design) <- c("ZT00","ZT04","ZT08","ZT12","ZT16","ZT20")

fit <- lmFit(expression.level, experiment.design)

contrast.matrix <- makeContrasts(ZT00-ZT04,ZT00-ZT08,ZT00-ZT12,ZT00-ZT16,ZT00-ZT20,ZT04-ZT08,ZT04-ZT12,ZT04-ZT16,ZT04-ZT20,ZT08-ZT12,ZT08-ZT16,ZT08-ZT20,ZT12-ZT16,ZT12-ZT20,ZT16-ZT20,levels=c("ZT00","ZT04","ZT08","ZT12","ZT16","ZT20"))

fit2 <- contrasts.fit(fit, contrast.matrix)
ebayes <- eBayes(fit2)

## Function to determine differentially expressed genes (DEGs)
DEG.selection <- function(processed.data,number.comparisons,number.genes,fold.change.threshold,log.pvalue.threshold)
{
  
  ## Initialize an empty character vector
  DEGs <- character()
  
  ## For loop to go through all the comparisons
  for(i in 1:number.comparisons)
  {
    ## Generate table with differential expression information
    DEGs.partial <- topTable(processed.data, number=number.genes,coef=i)
    ## Extract fold-change, q-value exponent and probe names form DE information
    fold.change <- DEGs.partial[["logFC"]]
    log.p.value <- -log10(DEGs.partial[["adj.P.Val"]])
    probe.names <- rownames(DEGs.partial)
    
    ## Determine activated genes as those exceeding the fold change threshold with the given statistical significance
    activated <- (fold.change > fold.change.threshold) & (log.p.value > log.pvalue.threshold)
    ## Determine activated genes as those exceeding the fold change threshold with the given statistical significance
    inhibited <- (fold.change < - fold.change.threshold) & (log.p.value > log.pvalue.threshold)
    
    ## Extract probe names for activated and inhibited genes
    activated.genes <- probe.names[activated]
    inhibited.genes <- probe.names[inhibited]
    
    ## Add the activated and inhibited genes in the current comparison to the accumulator of DEGs
    DEGs <- c(DEGs, activated.genes, inhibited.genes)
  }
  
  ## Output the accumulator of DEGs after removing repetitions
  return(unique(DEGs))
}

diff.expr.genes <- DEG.selection(processed.data=ebayes,number.comparisons=15,number.genes=22810,fold.change.threshold=1,log.pvalue.threshold=2)
length(diff.expr.genes)

diff.expr <- mean.expression[,diff.expr.genes]

## ¿Cuál es el número total de genes expresados de forma diferencial en este período de 12 horas
#   de luz y 12 horas de oscuridad?

## 2197

## Paso 2: Análisis de la correlación entre los perfiles de expresión génicos.
## Calcula la matriz de correlación entre los perfiles de los DEGs del paso anterior.

gene.correlation <- cor(diff.expr)
dim(gene.correlation)
## Paso 3: Construcción de la red, determinación de la matriz de adyacencia. 
## Elige un umbral de corte que produzca una buena aproximación a una red libre de escala y que
## a la vez cada gen tenga en promedio más de 10 vecinos.

library(igraph)
thresholds <- seq(from=0.70,to=0.99,by=0.01)
mean.connectivities <- vector(length=length(thresholds))
scale.free.R2 <- vector(length=length(thresholds))

## Go through all the correlation thresholds
for(i in 1:length(thresholds))
{
  print(thresholds[i])
  ## Construct the network corresponding to the current threshold being checked
  ## Adjacency matrix
  current.adjacency <- (gene.correlation > thresholds[i] & gene.correlation < 1) 
  ## Network
  threshold.network <- graph.adjacency(current.adjacency, mode="undirected")
  
  ## Compute node degrees
  node.degrees <- degree(threshold.network)
  
  ## Keep track of the mean connectivity or mean node degree of the current network
  mean.connectivities[i] <- mean(node.degrees)
  
  ## Check scale free property
  h <- hist(node.degrees)
  ## Compute degree frequencies
  degree.frequencies <- table(node.degrees)
  ## Determine linear regression for logarithmic transformed degree frequencies
  lm.r <- lm(log10(as.numeric(names(degree.frequencies[-1]))) ~ log10(degree.frequencies[-1]))
  ## Extract R squared as a measure of adjustment to the scale free property
  s.lm <- summary(lm.r)
  scale.free.R2[i] <- s.lm[["adj.r.squared"]]
}

plot(thresholds,mean.connectivities,type="o",col="red",lwd=3,xlab="Correlation Threshold",ylab="Mean connectivity")
plot(thresholds,scale.free.R2,type="o",col="blue",lwd=3,xlim=c(0.70,0.99),xlab="Correlation Threshold",ylab="Scale Free Model Fit (R²)")

names(mean.connectivities) <- thresholds
names(scale.free.R2) <- thresholds

mean.connectivities
scale.free.R2

## ¿Cuál es el umbral de corte elegido?
## 0.98

adjacency.098 <- (gene.correlation > 0.98) & (gene.correlation < 1)
gene.coexpression.network <- graph.adjacency(adjacency.098, mode="undirected")
write.graph(gene.coexpression.network,file="ath_gene_coexpression_network.gml",format="gml")

##¿Cuántos nodos y aristas tiene la red construída?
## 2197 y 14655

## Para leer una red en formato gml
gene.coexpression.network <- read.graph(file="ath_gene_coexpression_network.gml",format="gml")

#######################################
## Estudio de la topología de la red ##
#######################################

## Distribución del grado de los nodos, ajuste a una red libre de escala
network.degree.distribution <- degree.distribution(gene.coexpression.network)
fit.scale.free <- power.law.fit(network.degree.distribution)
fit.scale.free[["KS.p"]]

network.degrees <- degree(gene.coexpression.network)
network.degrees
degree.histogram <- hist(network.degrees,freq=FALSE,col="blue",xlab="Node degree", ylab="Probability",main="Degree distribution")

# Calculo del grado de los nodos
network.degrees <- degree(gene.coexpression.network)
# Calculo de la frecuencia absoluta del grado de los nodos
degree.frequencies <- table(network.degrees)
# Eliminamos nodos con grado 0 para poder aplicar log10
degree.frequencies.no.0 <- degree.frequencies[-1]

# Transformación logarítmica
log10.degrees.frequencies <- log10(degree.frequencies.no.0)
log10.node.degrees <- log10(as.numeric(names(degree.frequencies.no.0)))

# Regresión lineal
lm.r <- lm(log10.degrees.frequencies ~ log10.node.degrees)
summary(lm.r)

## Identificación de los hubs y generación de los ficheros de atributos, txt y html.
network.hub.scores <- hub.score(gene.coexpression.network)
hub.score.attributes <-network.hub.scores[["vector"]]

write.table(hub.score.attributes,file="hub_score_attributes.txt")

quatile.095 <- quantile(hub.score.attributes,prob=0.95)

hubs.values <- hub.score.attributes[hub.score.attributes > quatile.095]
hubs.names <- names(hubs.values)

library(annaffy)
source("http://bioconductor.org/biocLite.R")
biocLite("ath1121501.db")

hubs.table <- aafTableAnn(hubs.names, "ath1121501.db", aaf.handler())
saveHTML(hubs.table, file="hubs_table.html")
saveText(hubs.table, file="hubs_table.txt")


## Coeficiente medio de agrupamiento, longitud media de camino mínimo y ajuste a red de 
## mundo pequeño
network.clustering.coefficient <- transitivity(gene.coexpression.network,type="global")

average.path.length(gene.coexpression.network, directed=FALSE)

## Evaluamos la variable para comprobar el número de nodos y aristas de la red.
gene.coexpression.network

## En cada paso se añade un nuevo nodo por lo tanto en promedio en cada paso deberíamos
## añadir el siguiente número de aristas numero_de_aristas/numero_de_nodos
14655/2197

## Ya se deben añadir un número entero de aristas redondeamos a la baja, añadimos todos los nodos
## menos el último y en el último paso al introducir el último nodo añadimos le resto de aristas.
14655/6

14655 - 2196*6
sum(c(rep(6,2196),1479))

## Generamos grafos aleatorios y calculamos su coeficiente de agrupamiento medio
number.of.added.edges <- c(rep(6,2196),1479) 
random.scale.free.graph <- barabasi.game(n=2197,out.seq=number.of.added.edges,directed=FALSE)
transitivity(random.scale.free.graph)

clustering.coefficients <- vector(length=1000)

for(i in 1:1000)
{
  print(i)
  random.scale.free.graph <- barabasi.game(n=2197,out.seq=number.of.added.edges,directed=FALSE)
  clustering.coefficients[i] <- transitivity(random.scale.free.graph)
}

sum(clustering.coefficients > network.clustering.coefficient) / 1000

node.transitivity <- transitivity(gene.coexpression.network,type = "local",isolates = "zero")

names(node.transitivity) <- names(V(gene.coexpression.network))
write.table(node.transitivity,file="node_transitivity.txt")

## Para la identificación de clusteres o grupos de genes co-expresados en la red necesitamos 
## instalar los siguientes paquetes.
source("http://bioconductor.org/biocLite.R")
biocLite("impute")
install.packages("WGCNA")
library("WGCNA")
library("cluster")
allowWGCNAThreads()

## La identificación de clústeres o grupos de elementos se basa en una medida de similitud.
## La medida de similitud seleccionada en este estudio es 1 - correlacion
similarity.matrix <- 1 - gene.correlation

## La función hclust usando la matriz de similitudes como distancias y el método promedio
## para recalcular distancias calcula el clustering jerárquico.
hierarchical.clustering <- hclust(as.dist(similarity.matrix),method="average")

## La función cutree permite cortar el árbol generado en el clustering jerárquico a distintas
## alturas para producir distintos números de clústeres.
hclust.2 <- cutree(hierarchical.clustering,k=2)
hclust.3 <- cutree(hierarchical.clustering,k=3)
hclust.4 <- cutree(hierarchical.clustering,k=4)
hclust.5 <- cutree(hierarchical.clustering,k=5)
hclust.6 <- cutree(hierarchical.clustering,k=6)
hclust.7 <- cutree(hierarchical.clustering,k=7)
hclust.8 <- cutree(hierarchical.clustering,k=8)
hclust.9 <- cutree(hierarchical.clustering,k=9)
hclust.10 <- cutree(hierarchical.clustering,k=10)

## La función pam usa la matriz de similitudes como distancias para determinar clústeres
## según el método de partición entorno a medoides.
pam.2 <- pam(as.dist(similarity.matrix),k=2,diss=TRUE)
pam.3 <- pam(as.dist(similarity.matrix),k=3,diss=TRUE)
pam.4 <- pam(as.dist(similarity.matrix),k=4,diss=TRUE)
pam.5 <- pam(as.dist(similarity.matrix),k=5,diss=TRUE)
pam.6 <- pam(as.dist(similarity.matrix),k=6,diss=TRUE)
pam.7 <- pam(as.dist(similarity.matrix),k=7,diss=TRUE)
pam.8 <- pam(as.dist(similarity.matrix),k=8,diss=TRUE)
pam.9 <- pam(as.dist(similarity.matrix),k=9,diss=TRUE)
pam.10 <- pam(as.dist(similarity.matrix),k=10,diss=TRUE)

## La función silhouette nos permite calcular la silueta de un clustering que sirve de medida
## para la bondad de dicho clustering.
sil2 <- silhouette(hclust.2,dist=similarity.matrix)
sil3 <- silhouette(hclust.3,dist=similarity.matrix)
sil4 <- silhouette(hclust.4,dist=similarity.matrix)
sil5 <- silhouette(hclust.5,dist=similarity.matrix)
sil6 <- silhouette(hclust.6,dist=similarity.matrix)
sil7 <- silhouette(hclust.7,dist=similarity.matrix)
sil8 <- silhouette(hclust.8,dist=similarity.matrix)
sil9 <- silhouette(hclust.9,dist=similarity.matrix)
sil10 <- silhouette(hclust.10,dist=similarity.matrix)

plot(sil3,col="blue")

hclust.sil.values <- c(summary(sil2)[["avg.width"]],summary(sil3)[["avg.width"]],summary(sil4)[["avg.width"]],summary(sil5)[["avg.width"]],summary(sil6)[["avg.width"]],summary(sil7)[["avg.width"]],summary(sil8)[["avg.width"]],summary(sil9)[["avg.width"]],summary(sil10)[["avg.width"]])

sil2 <- silhouette(pam.2)
sil3 <- silhouette(pam.3)
sil4 <- silhouette(pam.4)
sil5 <- silhouette(pam.5)
sil6 <- silhouette(pam.6)
sil7 <- silhouette(pam.7)
sil8 <- silhouette(pam.8)
sil9 <- silhouette(pam.9)
sil10 <- silhouette(pam.10)

pam.sil.values <- c(summary(sil2)[["avg.width"]],summary(sil3)[["avg.width"]],summary(sil4)[["avg.width"]],summary(sil5)[["avg.width"]],summary(sil6)[["avg.width"]],summary(sil7)[["avg.width"]],summary(sil8)[["avg.width"]],summary(sil9)[["avg.width"]],summary(sil10)[["avg.width"]])

## Representamos para los dos métodos de clustering, jerárquico y pam, y para diferentes números
## de clústeres la silueta correspondiente para elegir la mejor combinación de método de 
## clustering y número de clústeres.
plot(2:10,pam.sil.values,type="o",col="blue",pch=0,ylim=c(0.3,0.8),xlab="Number of clusters",ylab="Silhouette",lwd=3)
lines(2:10,hclust.sil.values,type="o",col="red",pch=1,xlab="",ylab="",lwd=3)
legend("topright",legend=c("PAM","HCLUST"),col=c("blue","red"),pch=c(0,1),lwd=3)

## Visualización de clústeres
pam.2[["clustering"]]

clustering.pam.2 <- pam.2[["clustering"]]
write.table(clustering.pam.2,file="pam_2.txt")

clustering.pam.4 <- pam.4[["clustering"]]
write.table(clustering.pam.4,file="pam_4.txt")

library(annaffy)

cluster1.pam4 <- names(which(pam.4[["clustering"]] == 1))
cluster2.pam4 <- names(which(pam.4[["clustering"]] == 2))
cluster3.pam4 <- names(which(pam.4[["clustering"]] == 3))
cluster4.pam4 <- names(which(pam.4[["clustering"]] == 4))

cluster1.pam4.table <- aafTableAnn(cluster1.pam4, "ath1121501.db", aaf.handler())
cluster2.pam4.table <- aafTableAnn(cluster2.pam4, "ath1121501.db", aaf.handler())
cluster3.pam4.table <- aafTableAnn(cluster3.pam4, "ath1121501.db", aaf.handler())
cluster4.pam4.table <- aafTableAnn(cluster4.pam4, "ath1121501.db", aaf.handler())

saveHTML(cluster1.pam4.table, file="cluster_1_annotation.html")
saveHTML(cluster2.pam4.table, file="cluster_2_annotation.html")
saveHTML(cluster3.pam4.table, file="cluster_3_annotation.html")
saveHTML(cluster4.pam4.table, file="cluster_4_annotation.html")

saveText(cluster1.pam4.table, file="cluster_1_annotation.txt")
saveText(cluster2.pam4.table, file="cluster_2_annotation.txt")
saveText(cluster3.pam4.table, file="cluster_3_annotation.txt")
saveText(cluster4.pam4.table, file="cluster_4_annotation.txt")

expr.cluster1.pam4 <- diff.expr[,cluster1.pam4]
expr.cluster2.pam4 <- diff.expr[,cluster2.pam4]
expr.cluster3.pam4 <- diff.expr[,cluster3.pam4]
expr.cluster4.pam4 <- diff.expr[,cluster4.pam4]

mean.profile.cluster1.pam4 <- rowMeans(expr.cluster1.pam4)
mean.profile.cluster2.pam4 <- rowMeans(expr.cluster2.pam4)
mean.profile.cluster3.pam4 <- rowMeans(expr.cluster3.pam4)
mean.profile.cluster4.pam4 <- rowMeans(expr.cluster4.pam4)

plot(mean.profile.cluster4.pam4,type="o",col="blue",ylim=c(7,10),xlab="Time",ylab="Expression Level",lwd=3,pch=0,main="Clusters 1 and 2")
lines(mean.profile.cluster2.pam4,type="o",col="red",lwd=3,pch=1)
legend("topright",legend=c("Cluster 1","Cluster 2"),col=c("blue","red"),pch=c(0,1),lwd=3)

plot(mean.profile.cluster3.pam4,type="o",col="green",ylim=c(7,10),xlab="Time",ylab="Expression Level",lwd=3,pch=0,main="Clusters 3 and 4")
lines(mean.profile.cluster1.pam4,type="o",col="yellow",lwd=3,pch=1)
legend("topright",legend=c("Cluster 3","Cluster 4"),col=c("green","yellow"),pch=c(0,1),lwd=3)
